
# VARE Persistence Simulation Project

This project simulates five Windows persistence techniques using Python. It is intended for educational use only and must be tested in a controlled virtual environment.

## Simulated Techniques

1. Copy executable to AppData
2. Add Registry Run key
3. Create Startup folder batch file
4. Schedule a task on logon
5. Create a fake Windows service
6. [Optional] Keylogger using pynput

## Usage

### Run Persistence Simulation
```bash
python vare_persistence_simulator.py
```

### Clean Up Persistence Techniques
```bash
python vare_persistence_simulator.py --clean
```

## Important Notes
- Requires `pynput`: Install with `pip install pynput`
- Run as administrator to allow service and task creation
- Use in a **virtual machine only** for safety

Project by: [Your Name]
